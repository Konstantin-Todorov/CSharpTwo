﻿//Write a program to convert hexadecimal numbers to their decimal representation.
using System;
using System.Collections.Generic;
class HexadecimalToDecimal
{
    static void Main()
    {
        Console.Write("Enter Hexadecimal number : ");
        string hexadecimalNumber = Console.ReadLine();
        hexadecimalNumber = hexadecimalNumber.ToUpper();
        int[] convertedNumber = new int[hexadecimalNumber.Length];
        for (int i = 0; i < hexadecimalNumber.Length; i++)
        {
            switch (hexadecimalNumber[i])
            {
                case 'A': convertedNumber[i] = 10; break;
                case 'C': convertedNumber[i] = 12; break;
                case 'D': convertedNumber[i] = 13; break;
                case 'E': convertedNumber[i] = 14; break;
                case 'F': convertedNumber[i] = 15; break;
                case 'B': convertedNumber[i] = 11; break;
                default: convertedNumber[i] = int.Parse(Convert.ToString(hexadecimalNumber[i])); break;
            }
        }
        int decimalNumber = 0;
        int power = hexadecimalNumber.Length - 1;
        for (int i = 0; i < convertedNumber.Length; i++)
        {
            decimalNumber += convertedNumber[i] * (int)Math.Pow(16, power);
            power--;
        }
        Console.WriteLine("The Decimal representation : {0}",decimalNumber);
    }
}
